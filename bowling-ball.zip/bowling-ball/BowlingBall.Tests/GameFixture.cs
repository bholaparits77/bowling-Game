﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        private Game game;

        public GameFixture()
        {
            game = new Game();
        }
        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        {
            var game = new Game();
            Roll(game, 0, 20);
            Assert.AreEqual(0, game.GetScore());
        }

        private void Roll(Game game, int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                game.Roll(pins);
            }
        }

        private void rollMany(int rolls, int pins)
        {
            for (int i = 0; i < rolls; i++)
            {
                game.Roll(pins);
            }
        }

        private void rollSpare()
        {
            game.Roll(6);
            game.Roll(4);
        }

        [TestMethod]
        public void TestAllOnes()
        {
            rollMany(20, 1);
            Assert.AreEqual(20, game.GetScore());
        }

        [TestMethod]
        public void TestOneSpare()
        {
            rollSpare();
            game.Roll(4);
            rollMany(17, 0);
            Assert.AreEqual(18, game.GetScore());
        }

        [TestMethod]
        public void TestOneStrike()
        {
            game.Roll(10);
            game.Roll(4);
            game.Roll(5);
            rollMany(17, 0);
            Assert.AreEqual(28, game.GetScore());
        }

        [TestMethod]
        public void TestPerfectGame()
        {
            rollMany(12, 10);
            Assert.AreEqual(300, game.GetScore());
        }

        [TestMethod]
        public void TestRandomGameNoExtraRoll()
        {
            game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 0 });
            Assert.AreEqual(131, game.GetScore());
        }

        [TestMethod]
        public void TestRandomGameWithSpareThenStrikeAtEnd()
        {
            game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 1, 10 });
            Assert.AreEqual(143, game.GetScore());
        }

        [TestMethod]
        public void TestRandomGameWithThreeStrikesAtEnd()
        {
            game.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 10, 10, 10 });
            Assert.AreEqual(163, game.GetScore());
        }
    }
}
